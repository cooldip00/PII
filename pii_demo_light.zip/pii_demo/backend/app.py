import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
import torch
import os
from pathlib import Path

app = FastAPI()

# Define paths relative to this script
BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR.parent / "frontend"
MODEL_PATH = r"D:\SLM_2\pii-ner-deberta-best"

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Model Configuration
print(f"Loading model from {MODEL_PATH}...")

try:
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
    model = AutoModelForTokenClassification.from_pretrained(MODEL_PATH)
    # Check if CUDA (GPU) is available
    device = 0 if torch.cuda.is_available() else -1

    # Load pipeline with device
    nlp = pipeline(
        "token-classification", 
        model=model, 
        tokenizer=tokenizer, 
        aggregation_strategy="simple", 
        device=device  # Add this argument
    )
    # nlp = pipeline("token-classification", model=model, tokenizer=tokenizer, aggregation_strategy="simple")
    print("Model loaded successfully!")
except Exception as e:
    print(f"Error loading model: {e}")
    nlp = None

# Serve Static Files (Frontend)
# Mount the frontend directory to serve static assets (if any)
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")
else:
    print(f"Warning: Frontend directory not found at {FRONTEND_DIR}")

@app.get("/")
async def read_index():
    return FileResponse(str(FRONTEND_DIR / "index.html"))

@app.post("/analyze")
async def analyze_text(request: Request):
    if nlp is None:
        return {"error": "Model not loaded properly."}
    
    data = await request.json()
    text = data.get("text", "")
    
    if not text:
        return {"entities": []}

    results = nlp(text)
    
    # Convert numpy types to python types for JSON serialization
    processed_results = []
    for entity in results:
        processed_results.append({
            "word": entity["word"],
            "entity_group": entity["entity_group"],
            "score": float(entity["score"]),
            "start": int(entity["start"]),
            "end": int(entity["end"])
        })
        
    return {"entities": processed_results}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)

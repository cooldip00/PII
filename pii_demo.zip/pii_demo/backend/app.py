import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
import torch
import os

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Model Configuration
MODEL_PATH = "D:\SLM_2\pii-ner-deberta-best"
print(f"Loading model from {MODEL_PATH}...")

try:
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
    model = AutoModelForTokenClassification.from_pretrained(MODEL_PATH)
    # Check if CUDA (GPU) is available
    device = 0 if torch.cuda.is_available() else -1

    # Load pipeline with device
    nlp = pipeline(
        "token-classification", 
        model=model, 
        tokenizer=tokenizer, 
        aggregation_strategy="simple", 
        device=device  # Add this argument
    )
    # nlp = pipeline("token-classification", model=model, tokenizer=tokenizer, aggregation_strategy="simple")
    print("Model loaded successfully!")
except Exception as e:
    print(f"Error loading model: {e}")
    nlp = None

# Serve Static Files (Frontend)
# Mount the frontend directory to serve static assets (if any)
app.mount("/static", StaticFiles(directory="../frontend"), name="static")

@app.get("/")
async def read_index():
    return FileResponse("../frontend/index.html")

@app.post("/analyze")
async def analyze_text(request: Request):
    if nlp is None:
        return {"error": "Model not loaded properly."}
    
    data = await request.json()
    text = data.get("text", "")
    
    if not text:
        return {"entities": []}

    results = nlp(text)
    
    # Convert numpy types to python types for JSON serialization
    processed_results = []
    for entity in results:
        processed_results.append({
            "word": entity["word"],
            "entity_group": entity["entity_group"],
            "score": float(entity["score"]),
            "start": int(entity["start"]),
            "end": int(entity["end"])
        })
        
    return {"entities": processed_results}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
